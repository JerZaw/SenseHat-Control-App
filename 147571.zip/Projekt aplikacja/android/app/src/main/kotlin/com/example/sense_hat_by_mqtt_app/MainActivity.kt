package com.example.sense_hat_by_mqtt_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

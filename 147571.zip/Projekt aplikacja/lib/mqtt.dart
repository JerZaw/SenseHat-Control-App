import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_server_client.dart';
import 'sense_hat_data.dart';
import 'package:collection/collection.dart';

Future<int> mqttSetup(
  MqttServerClient client,
) async {
  /// Set the correct MQTT protocol for mosquito
  client.setProtocolV311();

  /// Add the unsolicited disconnection callback
  client.onDisconnected = onDisconnected;

  /// Add the successful connection callback
  client.onConnected = onConnected;

  /// Add a subscribed callback
  client.onSubscribed = onSubscribed;

  /// Create a connection message to use or use the default one. The default one sets the
  /// client identifier, any supplied username/password and clean session,
  /// an example of a specific one below.
  final connMess = MqttConnectMessage()
      .withClientIdentifier('jerzix-raspberry-python')
      .withWillTopic('willtopic') // If you set this you must set a will message
      .withWillMessage('My Will message')
      .startClean() // Non persistent session for testing
      .withWillQos(MqttQos.atLeastOnce);
  if (kDebugMode) {
    print('EXAMPLE::Mosquitto client connecting....');
  }
  client.connectionMessage = connMess;

  /// Connect the client, any errors here are communicated by raising of the appropriate exception. Note
  /// in some circumstances the broker will just disconnect us, see the spec about this, we however will
  /// never send malformed messages.
  try {
    await client.connect();
  } on NoConnectionException catch (e) {
    // Raised by the client when connection fails.
    if (kDebugMode) {
      print('EXAMPLE::client exception - $e');
    }
    client.disconnect();
  } on SocketException catch (e) {
    // Raised by the socket layer
    if (kDebugMode) {
      print('EXAMPLE::socket exception - $e');
    }
    client.disconnect();
  }

  /// Check we are connected
  if (client.connectionStatus!.state == MqttConnectionState.connected) {
    if (kDebugMode) {
      print('EXAMPLE::Mosquitto client connected');
    }
  } else {
    /// Use status here rather than state if you also want the broker return code.
    if (kDebugMode) {
      print(
          'EXAMPLE::ERROR Mosquitto client connection failed - disconnecting, status is ${client.connectionStatus}');
    }
    client.disconnect();
    exit(-1);
  }

  /// Ok, lets try a subscription
  if (kDebugMode) {
    print('Subscribing to the jerzix/iot/raspberry topic');
  }
  const topic = 'jerzix/iot/raspberry'; // Not a wildcard topic
  client.subscribe(topic, MqttQos.atMostOnce);

  /// The client has a change notifier object(see the Observable class) which we then listen to to get
  /// notifications of published updates to each subscribed topic.
  client.updates!.listen((List<MqttReceivedMessage<MqttMessage?>>? c) {
    final recMess = c![0].payload as MqttPublishMessage;
    final pt =
        MqttPublishPayload.bytesToStringAsString(recMess.payload.message);

    /// The above may seem a little convoluted for users only interested in the
    /// payload, some users however may be interested in the received publish message,
    /// lets not constrain ourselves yet until the package has been in the wild
    /// for a while.
    /// The payload is a byte buffer, this will be specific to the topic
    // if (kDebugMode) {
    //   print(
    //     'EXAMPLE::Change notification:: topic is <${c[0].topic}>, payload is <-- $pt -->');
    // }
    onMessage(pt);
  });

  /// Lets publish to our topic
  /// Use the payload builder rather than a raw buffer
  /// Our known topic to publish to
  // const pubTopic = 'jerzix/mis/android/';
  // final builder = MqttClientPayloadBuilder();
  // builder.addString('Hello from mqtt_client');
  // client.publishMessage(pubTopic, MqttQos.exactlyOnce, builder.payload!);

  return 0;
}

void onMessage(String body) {
// {"temperature": 22, "humidity" : 98, "acceleration": {"X": 0, "Y": 0: "Z" : 0}, "orientation": {"X": 0, "Y": 0: "Z" : 0}}
// {"leds": [["R":0,"G":0,"B":0], ["R":0,"G":0,"B":0], ["R":0,"G":0,"B":0], ...]}
  var messageData = jsonDecode(body);

  // change value
  SenseHatData.sensorList[0].value = messageData["temperature"].toStringAsPrecision(3);
  SenseHatData.sensorList[1].value = messageData["humidity"].toStringAsPrecision(3);
  SenseHatData.sensorList[2].xValue = messageData["acceleration"]["X"].toStringAsPrecision(3);
  SenseHatData.sensorList[2].yValue = messageData["acceleration"]["Y"].toStringAsPrecision(3);
  SenseHatData.sensorList[2].zValue = messageData["acceleration"]["Z"].toStringAsPrecision(3);
  SenseHatData.sensorList[3].xValue = messageData["orientation"]["X"].toStringAsPrecision(3);
  SenseHatData.sensorList[3].yValue = messageData["orientation"]["Y"].toStringAsPrecision(3);
  SenseHatData.sensorList[3].zValue = messageData["orientation"]["Z"].toStringAsPrecision(3);

  var previousDiodeList = SenseHatData.diodeList;

  var newDiodeList = List.generate(64, (index) {
    return Color.fromRGBO(messageData["leds"][index]["R"],
        messageData["leds"][index]["G"], messageData["leds"][index]["B"], 1);
  });

  if (!ListEquality().equals(previousDiodeList,newDiodeList)){
    SenseHatData.diodeList = previousDiodeList;
  }

  SenseHatData.notifyParent!();
}

/// The subscribed callback
void onSubscribed(String topic) {
  if (kDebugMode) {
    print('EXAMPLE::Subscription confirmed for topic $topic');
  }
}

/// The unsolicited disconnect callback
void onDisconnected() {
  if (kDebugMode) {
    print('EXAMPLE::OnDisconnected client callback - Client disconnection');
  }
}

/// The successful connect callback
void onConnected() {
  if (kDebugMode) {
    print(
        'EXAMPLE::OnConnected client callback - Client connection was successful');
  }
}

int customPublish(MqttServerClient client) {
  const baseTopic = 'jerzix/iot/android';
  final builder = MqttClientPayloadBuilder();
  // {"temperature": 0.0, "humidity": 0.0, "acceleration": {"X": 0.0, "Y": 0.0, "Z": 0.0}, "orientation": {"X": 0.0, "Y": 0.0, "Z": 0.0},
  // "leds": [{"R": 100, "G": 100, "B": 255}, {"R": 100, "G": 100, "B": 255}, {"R": 100, "G": 100, "B": 255}...
  String data = '[';
  for (int i = 0; i < 64; i++) {
    data +=
        '{"R": ${SenseHatData.diodeList[i].red.toString()}, "G": ${SenseHatData.diodeList[i].green.toString()}, "B": ${SenseHatData.diodeList[i].blue.toString()}},';
  }
  data = data.substring(0,data.length-1);
  data+=']';

  builder.addString(data);
  return client.publishMessage(
      baseTopic, MqttQos.exactlyOnce, builder.payload!);
}

int toInt(bool val) => val ? 1 : 0;

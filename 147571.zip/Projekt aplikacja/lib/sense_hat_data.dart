import 'package:flutter/material.dart';

class Sensor {
  String name = "";
  String unit = "-";
  bool simple = true;

  Sensor(this.name, this.unit);
}

class SensorSimple extends Sensor {
  String value = '';

  SensorSimple(super.name, super.unit) {
    super.simple = true;
  }
}

class SensorComplicated extends Sensor {
  String xValue = '';
  String yValue = '';
  String zValue = '';

  SensorComplicated(super.name, super.unit) {
    super.simple = false;
  }
}

class SenseHatData {
  static List<Color> setDiodeList() {
    return List.generate(64, (index) {
      return const Color.fromRGBO(0, 0, 0, 1);
    });
  }
  static List setSensorList() {
    return [
      SensorSimple("temperature", " \u00B0 C"),
      SensorSimple("humidity", " %"),
      SensorComplicated("acceleration", " G"),
      SensorComplicated("orientation", " \u00B0"),
    ];
  }

  static Function()? notifyParent;

  static List<Color> diodeList = setDiodeList();
  static List sensorList = setSensorList();

  static void resetData() {
    diodeList = setDiodeList();
    sensorList = setSensorList();
  }
}

import 'package:flex_color_picker/flex_color_picker.dart';
import 'package:flutter/material.dart';

import 'package:mqtt_client/mqtt_server_client.dart';
import 'mqtt.dart';
import 'sense_hat_data.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  final myHomePage = const MyHomePage(title: 'SenseHat Control');

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SenseHat Control',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: myHomePage,
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final client =
      MqttServerClient('test.mosquitto.org', 'jerzix-raspberry-python');
      // MqttServerClient('192.168.5.1:1883', 'jerzix-raspberry-python');

  void resetButton() {
    SenseHatData.resetData();
    sendData();
  }

  void setStateCallback() {
    setState(() {});
  }

  String generateSensorLine(int index) {
    String display = SenseHatData.sensorList[index].name + ": ";

    if (SenseHatData.sensorList[index].simple) {
      display += SenseHatData.sensorList[index].value.toString() +
          SenseHatData.sensorList[index].unit;
    } else {
      display +=
          "${SenseHatData.sensorList[index].xValue.toString() + SenseHatData.sensorList[index].unit}, ";
      display +=
          "${SenseHatData.sensorList[index].yValue.toString() + SenseHatData.sensorList[index].unit}, ";
      display += SenseHatData.sensorList[index].zValue.toString() +
          SenseHatData.sensorList[index].unit;
    }

    return display;
  }

  Future<bool> colorPickerDialog(int index, BuildContext context) async {
    return ColorPicker(
      // Use the dialogPickerColor as start color.
      color: SenseHatData.diodeList[index],
      // Update the dialogPickerColor using the callback.
      onColorChanged: (Color color) => setState(() {
        SenseHatData.diodeList[index] = color;
      }),
      width: 40,
      height: 40,
      borderRadius: 4,
      spacing: 5,
      runSpacing: 5,
      wheelDiameter: MediaQuery.of(context).size.width - 50,
      heading: Text(
        'Select diode color',
        style: Theme.of(context).textTheme.titleSmall,
      ),
      subheading: Text(
        'Select color shade',
        style: Theme.of(context).textTheme.titleSmall,
      ),
      wheelSubheading: Text(
        'Selected color and its shades',
        style: Theme.of(context).textTheme.titleSmall,
      ),
      showMaterialName: false,
      showColorName: false,
      showColorCode: false,
      copyPasteBehavior: const ColorPickerCopyPasteBehavior(
        longPressMenu: true,
      ),
      materialNameTextStyle: Theme.of(context).textTheme.bodySmall,
      colorNameTextStyle: Theme.of(context).textTheme.bodySmall,
      colorCodeTextStyle: Theme.of(context).textTheme.bodySmall,
      pickersEnabled: const <ColorPickerType, bool>{
        ColorPickerType.both: false,
        ColorPickerType.primary: false,
        ColorPickerType.accent: false,
        ColorPickerType.bw: false,
        ColorPickerType.custom: false,
        ColorPickerType.wheel: true,
      },
      // customColorSwatchesAndNames: colorsNameMap,
    ).showPickerDialog(
      context,
      // New in version 3.0.0 custom transitions support.
      transitionBuilder: (BuildContext context, Animation<double> a1,
          Animation<double> a2, Widget widget) {
        final double curvedValue =
            Curves.easeInOutBack.transform(a1.value) - 1.0;
        return Transform(
          transform: Matrix4.translationValues(0.0, curvedValue * 200, 0.0),
          child: Opacity(
            opacity: a1.value,
            child: widget,
          ),
        );
      },
      transitionDuration: const Duration(milliseconds: 400),
      constraints:
          const BoxConstraints(minHeight: 460, minWidth: 300, maxWidth: 320),
    );
  }

  void sendData() {
    //send all data
    customPublish(client);
    setState(() {});
  }

  void initializeMqtt() async {
    SenseHatData.notifyParent = setStateCallback;
    await mqttSetup(client);
  }

  @override
  void initState() {
    super.initState();
    initializeMqtt();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Column(
        children: <Widget>[
          Flexible(
            flex: 23,
            child: Padding(
              padding: const EdgeInsets.all(0),
              child: GridView.count(
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisCount: 8,
                  children: List.generate(64, (index) {
                    return Padding(
                      padding: const EdgeInsets.all(3.0),
                      child: ElevatedButton(
                        onPressed: () {},
                        style: ButtonStyle(
                          padding: MaterialStateProperty.all<EdgeInsets>(
                              const EdgeInsets.all(0)),
                          alignment: Alignment.center,
                          shape: MaterialStateProperty.all(
                              const BeveledRectangleBorder()),
                          backgroundColor: MaterialStateProperty.all<Color>(
                              SenseHatData.diodeList[index]),
                          foregroundColor:
                              MaterialStateProperty.all<Color>(Colors.white),
                        ),
                        // child: Text(
                        //   "$index",
                        //   style: const TextStyle(fontSize: 14),
                        // ),
                        child: ColorIndicator(
                          width: 44,
                          height: 44,
                          borderRadius: 4,
                          color: SenseHatData.diodeList[index],
                          onSelectFocus: false,
                          onSelect: () async {
                            // Store current color before we open the dialog.
                            final Color colorBeforeDialog =
                                SenseHatData.diodeList[index];
                            // Wait for the picker to close, if dialog was dismissed,
                            // then restore the color we had before it was opened.
                            if (!(await colorPickerDialog(index, context))) {
                              setState(() {
                                SenseHatData.diodeList[index] =
                                    colorBeforeDialog;
                              });
                            } else {
                              sendData();
                            }
                          },
                        ),
                      ),
                    );
                    //   return ListTile(
                    //     onTap: (){},
                    //     title: Text("$index", style: TextStyle(fontSize: 10),),
                    //   );
                  })),
            ),
          ),
          Flexible(
            flex: 10,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(SenseHatData.sensorList.length, (index) {
                return Text(generateSensorLine(index));
              }),
            ),
          ),
          Flexible(
            flex: 10,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(
                  width: 100,
                  child: ElevatedButton(
                    onPressed: resetButton,
                    child: const Text(
                      "RESET",
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

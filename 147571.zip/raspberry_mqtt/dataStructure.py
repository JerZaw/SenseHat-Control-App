# {"temperature": 22, "humidity" : 98, "acceleration": {"X": 0, "Y": 0: "Z" : 0}, "orientation": {"X": 0, "Y": 0: "Z" : 0}}
# {"leds": [["R":0,"G":0,"B":0], ["R":0,"G":0,"B":0], ["R":0,"G":0,"B":0], ...]} 

def generateLedsList(sizeOfList):
 
  # Create empty list
  res = []
 
  # loop to append successors to
  # list until r2 is reached.
  index = 0
  while(index < sizeOfList):
    
   res.append({"R":0,"G":0,"B":0})
   index += 1
  return res

data = {
  "temperature": 0.0,
  "humidity": 0.0,
  "acceleration": {"X" : 0.0, "Y": 0.0, "Z" : 0.0},
  "orientation": {"X": 0.0, "Y": 0.0, "Z" : 0.0},
  "leds": generateLedsList(64)
}
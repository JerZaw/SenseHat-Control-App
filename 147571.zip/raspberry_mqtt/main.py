import time
import paho.mqtt.client as mqtt
from sense_hat import SenseHat
# from sense_emu import SenseHat

import mqttManagement
import dataStructure

data_interval = 0.05
my_client = mqtt.Client()
mqttManagement.mqtt_setup(my_client)

sense = SenseHat()
sense.clear()

def measureSenseHatSensors():
    global dataStructure
    dataStructure.data["temperature"] = sense.get_temperature()
    dataStructure.data["humidity"] = sense.get_humidity()

    acceleration = sense.get_accelerometer_raw()
    dataStructure.data["acceleration"]["X"] = acceleration['x']
    dataStructure.data["acceleration"]["Y"] = acceleration['y']
    dataStructure.data["acceleration"]["Z"] = acceleration['z']

    orientation = sense.get_orientation()
    dataStructure.data["orientation"]["X"] = orientation['roll']
    dataStructure.data["orientation"]["Y"] = orientation['pitch']
    dataStructure.data["orientation"]["Z"] = orientation['yaw']

def setDiodesData(my_sense):
    tempList = []
    for i in dataStructure.data["leds"]:
        tempList.append((i["R"], i["G"], i["B"]))
    my_sense.set_pixels(tempList)
        

#main loop
while True:
    mqttManagement.send_data(my_client, dataStructure.data) 
    
    measureSenseHatSensors()
    setDiodesData(sense)

    time.sleep(data_interval) #how long to wait for the next loop
import json
import urllib.request

import dataStructure

# listening for the goal_temperature data from android app
def on_connect(client, userdata, flags, rc):
    if rc==0:
        print("MQTT connected clien_pos OK Returned code=",rc)
        client.subscribe("jerzix/iot/android")
    else:
        print("Bad connection Returned code=",rc)

# reading the goal_temperature
def on_message(client, userdata, message):
    print(f"message received: message topic  {message.topic}")
    # print("message received  "  ,str(message.payload.decode("utf-8")))
    json_data = json.loads(message.payload.decode("utf-8"))
    global dataStructure
    dataStructure.data["leds"] = json_data
    
def send_data(client, myData):
    dataJson = json.dumps(myData)
    client.publish("jerzix/iot/raspberry",dataJson)

def wait_for_internet_connection():
    while True:
        try:
            response = urllib.request.urlopen("https://test.mosquitto.org/",timeout=5)
            return
        except urllib.request.HTTPError:
            pass

# MQTT main setup
def mqtt_setup(my_client):
    broker_address="test.mosquitto.org" #name of the free mqtt broker

    my_client.on_connect = on_connect
    my_client.on_message = on_message

    my_client.connect(broker_address, 1883, 60)
    my_client.loop_start()
